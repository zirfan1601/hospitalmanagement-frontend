var BACKEND_URL, FRONTEND_URL;

// if (process.env.NODE_ENV === "production") {

//     BACKEND_URL = "https://api.kgpverse.chiragghosh.me";
//     FRONTEND_URL = "https://kgpverse.chiragghosh.me";
// }

// else if (process.env.NODE_ENV === "development") {

//     BACKEND_URL = "http://localhost:8000";
//     FRONTEND_URL = "http://localhost:3000";
// }

BACKEND_URL = "http://localhost:8000";
FRONTEND_URL = "http://localhost:3000";

export { BACKEND_URL, FRONTEND_URL };
